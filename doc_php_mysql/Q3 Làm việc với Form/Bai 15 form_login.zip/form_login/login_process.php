<?php
$user = [
    "username" => "chung",
    "password" => "123"
];
if(!empty($_POST)) {
    echo "<pre class='text-left'>";
    var_dump($_POST);
    echo "</pre>";
    $username = $_POST["form-username"];
    $pass = $_POST["form-password"];
    if($user["username"] == $username && $user["password"] == $pass) {
//        echo "<h1>Welcome, <strong>$username</strong></h1>";
        header('Location: https://google.com/');
    } else {
        echo "<pre>Sai tên đăng nhập hoặc mật khẩu</pre>";
    }
}
?>