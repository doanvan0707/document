<?php

$listUser = [
    'chungvh',
    'huynt',
    'namnv',
    'vuongmanh',
    'antam',
    'binhtm',
    'duongtranmanh',
    'trangtt',
    'robin',
    'jolly',
    'quyennt',
    'manhhai'
];

echo json_encode($listUser);