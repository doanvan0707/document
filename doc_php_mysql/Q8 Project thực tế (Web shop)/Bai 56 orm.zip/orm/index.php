<?php

use Doctrine\ORM\Tools\Setup;
use Doctrine\ORM\EntityManager;

require_once "vendor/autoload.php";

$settings = [

            'meta' => [
                'entity_path' => [
                    __DIR__ . '/src'
                ],
                'auto_generate_proxies' => true,
                'proxy_dir' =>  __DIR__.'/../cache/proxies',
                'cache' => null,
            ],
            'connection' => [
                'driver' => 'pdo_pgsql',
			    'host' => 'localhost',
			    'port' => '5432',
			    'user' => 'postgres',
			    'password' => '123',
			    'dbname' => 'tododb',
			    'charset' => 'utf8',
            ]
];

    $config = \Doctrine\ORM\Tools\Setup::createAnnotationMetadataConfiguration(
        $settings['meta']['entity_path'],
        $settings['meta']['auto_generate_proxies'],
        $settings['meta']['proxy_dir'],
        $settings['meta']['cache'],
        false
    );
    $em = \Doctrine\ORM\EntityManager::create($settings['connection'], $config);
    // check if connection is alive
    try {
        $em->getConnection()->connect();
    } catch (\Exception $e) {
        echo $e->getMessage();
        die;
    }

    $tasks = $em->getRepository('Task')->findAll();
    var_dump($tasks);